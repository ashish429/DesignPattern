package designPattern.behaviourDeasignPattern.observer;

import designPattern.behaviourDeasignPattern.observer.DeliveryData.Observer;

abstract class DeliveryWarehouseCenter implements Observer {

	private String email;
	private String subject;
	private String message;

	@Override
	public void update(String email, String subject, String message) {
		this.email = email;
		this.subject = subject;
		this.message = message;
		showMessage();
	}

	public void showMessage() {
		System.out.println("Email: " + email);
		System.out.println("Subject: " + subject);
		System.out.println("Message: " + message);
	}
}
