package designPattern.behaviourDeasignPattern.observer;

import java.util.ArrayList;
import java.util.List;
interface Subject {
	void register(designPattern.behaviourDeasignPattern.observer.DeliveryData.Observer obj);

	void unregister(designPattern.behaviourDeasignPattern.observer.DeliveryData.Observer obj);

	void notifyObservers();
}
abstract class DeliveryData implements Subject {

	private List<Observer> observers;
	private String email;
	private String subject;
	private String messageBody;

	public DeliveryData() {
		this.observers = new ArrayList<>();
	}

	@Override
	public void register(Observer obj) {
		observers.add(obj);
	}

	@Override
	public void unregister(Observer obj) {
		observers.remove(obj);
	}

	@Override
	public void notifyObservers() {
		for (Observer obj : observers) {
			obj.update(email);
			obj.update(subject);
			obj.update(messageBody);
		}
	}

	public void messageChanged() {
		this.email = getEmail();
		this.subject = getSubject();
		this.messageBody = getMessageBody();
		notifyObservers();
	}

	public String getEmail() {
		return "ashishshukla12@gmail.com";
	}

	public String getSubject() {
		return "Project Completion";
	}

	public String getMessageBody() {
		return "Ashish project Complete day is 12 August 2023";
	}

	interface Observer {
		public void update(String message);

		void update(String email, String subject, String message);
	}




}
