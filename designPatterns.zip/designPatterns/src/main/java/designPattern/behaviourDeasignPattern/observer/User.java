package designPattern.behaviourDeasignPattern.observer;

import designPattern.behaviourDeasignPattern.observer.DeliveryData.Observer;

abstract class User implements Observer {
	private String message;
	private String email;
	private String subject;

	@Override
	public void update(String message) {
		this.message = message;
		showMessage();
	}

	public void showMessage() {
		System.out.println("Email: " + email);
		System.out.println("Subject: " + subject);
		System.out.println("Message: " + message);
	}
}
