package designPattern.creationalDesignPattern;

public class CommunicationFactory {

	public Communication getProcess(String messageType) {
		if ("email".equalsIgnoreCase(messageType)) {
			return new EmailCommunication();
		} else if ("Sms".equalsIgnoreCase(messageType)) {
			return (Communication) new SmsCommunication();
		}
		return null;

	}

}
