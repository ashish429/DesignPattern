package designPattern.creationalDesignPattern;

public class SmsCommunication implements Communication {

	public void process(Message message) {
		System.out.println("SMS :" + message.getSms());
		System.out.println("Subject :" + message.getSubject());
		System.out.println(message.getMessageBody());

	}
}
