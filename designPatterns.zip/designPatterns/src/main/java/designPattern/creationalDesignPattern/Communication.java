package designPattern.creationalDesignPattern;

public interface Communication {
	public void process(Message message);
}
