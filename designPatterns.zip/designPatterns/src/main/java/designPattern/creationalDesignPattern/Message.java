package designPattern.creationalDesignPattern;

public class Message {

	private String email;
	private String sms;
	private String subject;
	private String messageType;
	private String messageBody;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getSms() {
		return sms;
	}

	public void setSms(String sms) {
		this.sms = sms;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getMessageBody() {
		return messageBody;
	}

	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

	public Message(String email, String sms,  String subject, String messageBody) {

		this.email = email;
		this.sms = sms;
		this.subject = subject;
		this.messageBody = messageBody;
	}

}
