package designPattern.creationalDesignPattern;

import java.util.ArrayList;
import java.util.List;

public class FactoryDesignPattern {
	public static void main(String[] args) {
		List<Message> message = messageList();
		Communication processor;
		CommunicationFactory factory = new CommunicationFactory();
		for (Message m : message) {
			if(m==null)
			{
				return;
			}
			processor = factory.getProcess(m.getMessageType());
			processor.process(m);
		}
		
	}

	private static List<Message> messageList() {
		List<Message> message = new ArrayList<>();

		Message m1 = new Message("ashishshukla123@gmail.com", "Ashish Shukla", "Project Completion",
				"Ashish project Complete day is 12 August 2023");
		Message m2 = new Message("himanshu@gmail.com", "Himanshu Singh", "Project Completion",
				"Himanshu please complete your properly this time");
		Message m3 = new Message("akash23@gmail.com", "Akash Choudhary", "Project Completion",
				"Akash your credit card due money is on 12 july 2023");
		Message m4 = new Message("ayushi.agarwal@gmail.com", "Ayushi Agarwall", "Project Completion",
				"Congrats to be the part of our Team");
		Message m5 = new Message("dineshrawat@gmail.com", "Dinesh Rawat", "Party Invitation",
				"Dinesh you invited for offive party on 26 August 2023");

		message.add(m1);
		message.add(m2);
		message.add(m3);
		message.add(m4);
		message.add(m5);
		return message;
	}

}
