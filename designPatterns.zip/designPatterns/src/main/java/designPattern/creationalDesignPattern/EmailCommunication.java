package designPattern.creationalDesignPattern;

public class EmailCommunication implements Communication {

	public void process(Message message) {
		System.out.println("Email :" + message.getEmail());
		System.out.println("Subject :" + message.getSubject());
		System.out.println(message.getMessageBody());

	}

}
