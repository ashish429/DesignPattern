package designPattern.structuralDesignPattern.Adaptor;

public class AdapterDesignPattern {
	 public static void main(String[] args) {
		    MessageTypeDriver a = new MessageTypeDriver();
		    a.getMessage();
		    a.selectMessage();
		    
		    MessageDriver  e = new MessageDriver();
		    e.findMessage();
		    e.clickMessage();
		    
		    WebDriver wID = new WebDriverAdapter(e);
		    wID.getMessage();
		    wID.selectMessage();
		    
		  }
}
