package designPattern.structuralDesignPattern.Adaptor;

public class MessageDriver {
	public void findMessage() {
	    System.out.println("Find subject from Email");
	  }

	  public void clickMessage() {
	    System.out.println("Click subject from Email");
	  }
	  
}
