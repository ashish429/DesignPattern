package designPattern.structuralDesignPattern.Adaptor;

public class MessageDriverAdapter implements NotificationDriver {
	@Override
	  public void getMessage() {
	    System.out.println("Get message from MessageTypeDriver");
	  }

	  @Override
	  public void selectMessage() {
	    System.out.println("Select message from MessageTypeDriver");
	    
	  }
}
