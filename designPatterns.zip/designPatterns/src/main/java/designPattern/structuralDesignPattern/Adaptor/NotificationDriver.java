package designPattern.structuralDesignPattern.Adaptor;

interface NotificationDriver {
	  public void getMessage();
	  public void selectMessage();
	}