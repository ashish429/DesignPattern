package designPattern.structuralDesignPattern.Adaptor;

public class MessageTypeDriver {
	public void getMessage() {
	    System.out.println("Get email from Message");
	  }

	
	  public void selectMessage() {
	    System.out.println("Select email from Message");
	    
	  }
}
